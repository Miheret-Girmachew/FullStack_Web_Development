
// How to test your JS 
	// console.log("HELLO WORLD");
	// alert("Selam");

// Declaring Variables

	var a = 5;
	let b = 3;	
	b = "7"; 
	b = 10;  
	var c;
	c = a + b; 
	console.log(a);

	var fullName = "";
	var firstName = "Adem";
	var lastName = " Wolde"; 
	fullName = firstName + lastName; 
	console.log(fullName);


	// Since 2016 (ES6)
	// let , const 
	let g = 8; 
	const m = 9;

	// console.log(c);


// // String Operators
// 	// Assignment and arithmetic operators are already covered above  
// 	var a = "Abebe"; 
// 	var b = " Kebede"; 
// 	var c = a + b; 
// 	// console.log(c);

// 	var a = 4; 
// 	var b = "Test"; 
// 	var c = a + b; 
// 	// console.log(c);

// Comparision 
	console.log(2 == "2");
	console.log(2 == "2");
	console.log(2 !== "2");	 


// // Logical Operators
// 	var a = 4; 
// 	var b = 5; 	
// 	var c = "5"; 
// 	// console.log(a == b || b === c);

// // Weak Typing
// 	// Don't worry about the if statment for now. Just focus on the out puts 
// 	// Which one will print in the code below 
	if ("false") {
		console.log("Hello");
	}else {
		console.log("Olla");
	}




	











